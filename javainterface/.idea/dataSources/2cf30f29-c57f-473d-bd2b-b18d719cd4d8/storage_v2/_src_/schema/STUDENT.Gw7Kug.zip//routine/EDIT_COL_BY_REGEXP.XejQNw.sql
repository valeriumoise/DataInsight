create PROCEDURE edit_col_by_regexp (
    regexp varchar2,
    mydata varchar2
) IS
    v_curr varchar(2);
    v_length_regexp number;
    v_length_mydata number;
BEGIN
    --arr_regexp := varray_char(regexp);
    --arr_mydata := varray_char(mydata);
    v_length_regexp := length(regexp);
    v_length_mydata := length(mydata);
    for elem in 1 .. v_length_regexp loop
        v_curr := SUBSTR(regexp,elem,1);
        dbms_output.put_line(v_curr);
  end loop;
END;
/

