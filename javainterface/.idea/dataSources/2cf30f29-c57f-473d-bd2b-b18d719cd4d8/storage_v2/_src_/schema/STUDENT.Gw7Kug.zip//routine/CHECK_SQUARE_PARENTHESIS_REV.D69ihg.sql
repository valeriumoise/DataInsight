create FUNCTION check_square_parenthesis_rev(
    square varchar2,
    mydata varchar2,
    dataindex number
) RETURN boolean
IS
    indexx number;
    square_size number;
BEGIN
    indexx := 1;
    square_size := length(square);
    LOOP
        if (indexx + 1<square_size+1) then
            if((SUBSTR(square,indexx+1,1)='-') AND (check_escape(square, indexx)=false)) then
                if(SUBSTR(square,indexx,1)<=SUBSTR(mydata,dataindex,1) AND SUBSTR(square,indexx+2,1)>=SUBSTR(mydata,dataindex,1)) then
                    return false;
                else
                    indexx := indexx+2;
                end if;
            elsif(INSTR(square,SUBSTR(mydata,dataindex,1),1,1)<>0) then
                return false;
            end if;
        elsif (INSTR(square,SUBSTR(mydata,dataindex,1),1,1)<>0) then
                return false;
        end if;
        indexx := indexx+1;
    EXIT WHEN(indexx>square_size);
    END LOOP;
    return true;
END;
/

