create FUNCTION check_square_parenthesis(
    square varchar2,
    mydata varchar2,
    dataindex number
) RETURN boolean
IS
    indexx number;
    square_size number;
BEGIN
    indexx := 1;
    square_size := length(square);
    --dbms_output.put_line(square);
    LOOP
        if (indexx + 1<square_size+1) then
            --dbms_output.put_line('intrare if 1');
            if((SUBSTR(square,indexx+1,1)='-') AND (check_escape(square, indexx)=false)) then
                --dbms_output.put_line('intrare if 2');
                if(SUBSTR(square,indexx,1)<=SUBSTR(mydata,dataindex,1) AND SUBSTR(square,indexx+2,1)>=SUBSTR(mydata,dataindex,1)) then
                    --dbms_output.put_line('intrare if 3 true');
                    return true;
                else
                    --dbms_output.put_line('intrare else 3.1');
                    indexx := indexx+2;
                end if;
            elsif(INSTR(square,SUBSTR(mydata,dataindex,1),1,1)<>0) then
                --dbms_output.put_line('intrare if 2.1 true');
                return true;
            end if;
        elsif (INSTR(square,SUBSTR(mydata,dataindex,1),1,1)<>0) then
            --dbms_output.put_line('intrare if 1.1 true');
            return true;
        end if;
        indexx := indexx+1;
        --dbms_output.put_line(indexx);
    EXIT WHEN(indexx>square_size);
    END LOOP;
    return false;
END;
/

