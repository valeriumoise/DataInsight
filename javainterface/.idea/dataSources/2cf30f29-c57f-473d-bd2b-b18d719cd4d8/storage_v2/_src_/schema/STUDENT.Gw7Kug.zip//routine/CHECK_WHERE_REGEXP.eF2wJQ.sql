create FUNCTION check_where_regexp(
    regexp varchar2,
    mydatafirst varchar2
) return return_type
IS
    v_length_mydatafirst number;
    v_this_index number;
    v_current_data varchar2(200);
    return_data return_type;
BEGIN
    return_data := return_type(0,0);
    my_public_package.my_global_index := 1;
--    return_data.poz_start := 0;
--    return_data.poz_finish := 0;
    v_length_mydatafirst := length(mydatafirst);
    v_this_index := 1;
    v_current_data := '';
    WHILE (v_this_index <= v_length_mydatafirst) LOOP
        v_current_data := SUBSTR(mydatafirst,v_this_index,(v_length_mydatafirst-v_this_index+1));
        my_public_package.my_global_index := 1;
        if(edit_col_by_regexp_f(regexp,v_current_data)=true) then
            return_data.poz_start := v_this_index;
            return_data.poz_finish := my_public_package.my_global_index-1+v_this_index-1;
            return return_data;
        end if;
        v_current_data := '';
        v_this_index := v_this_index+1;
    END LOOP;   
    return return_data;
END;
/

