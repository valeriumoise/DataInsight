create FUNCTION check_escape(
    exp varchar2,
    poz number
) RETURN boolean
IS
BEGIN
    if(poz<1) then
        return false;
    end if;
    if(SUBSTR(exp,poz,1)='\') then
        return true;
    end if;
    return false;
END;
/

